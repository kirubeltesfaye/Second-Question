import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class FacebookAutomation {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver","chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.navigate().to("https://www.facebook.com/");

        driver.findElement(By.name("email")).sendKeys("fikru.tesfaye@ymail.com");
        driver.findElement(By.name("pass")).sendKeys("dontdothiss");
        //driver.findElement(By.xpath("//*[@id='pass']")).sendKeys("haymihaymi");
        driver.findElement(By.xpath("//*[@id='u_0_2']")).click();

        List<WebElement> notsize  =  driver.findElements(By.xpath("//*[@id='notificationsCountValue']"));
        System.out.println("total notification ->" + notsize.size());
//        List<WebElement> notification = driver.findElements(By.xpath("//*[@id=\"js_3b\"]/div/div/ul/li[1]/div/ul/li"));
//        for (WebElement e : notification)
//        System.out.println(notification.getText());

        if(notsize.size() >= 1){

                emailReport.main(args);


//            WebDriver gdriver = new ChromeDriver();
//        gdriver.navigate().to("https://mail.google.com");
//        gdriver.findElement(By.xpath("//*[@id='identifierId']")).sendKeys("sintemita@gmail.com");
//
//
//        gdriver.findElement(By.xpath("//*[@id='identifierNext']/content/span")).click();
//        try {
//            Thread.sleep(10000);
//        }catch (Exception E){
//
//        }
//        driver.findElement(By.cssSelector("#password > div.aCsJod.oJeWuf > div > div.Xb9hP > input")).sendKeys("12345abcd1234567890");
//        driver.findElement(By.xpath("//*[@id='passwordNext']/content/span")).click();
        try {
            Thread.sleep(10000);
        }catch (Exception E){

        }
        driver.close();
      }


      }
}
